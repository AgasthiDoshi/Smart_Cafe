package com.smartcafe.management;

public interface Billable {
    void generateBill();
}
