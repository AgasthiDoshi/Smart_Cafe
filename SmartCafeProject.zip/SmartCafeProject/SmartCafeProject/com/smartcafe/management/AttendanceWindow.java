package com.smartcafe.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AttendanceWindow extends JFrame {
    private Attendance attendance;
    private JTextField staffIdField;
    private DefaultTableModel tableModel;

    public AttendanceWindow() {
        attendance = new Attendance();

        setTitle("Staff Attendance");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Top Panel - Input + Buttons
        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(new JLabel("Staff ID:"));
        staffIdField = new JTextField(15);
        topPanel.add(staffIdField);

        JButton punchInButton = new JButton("Punch In");
        JButton punchOutButton = new JButton("Punch Out");

        topPanel.add(punchInButton);
        topPanel.add(punchOutButton);

        add(topPanel, BorderLayout.NORTH);

        // Center Panel - Attendance Log Table
        tableModel = new DefaultTableModel(new Object[]{"Staff ID", "Action", "Date & Time"}, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Button Listeners
        punchInButton.addActionListener(e -> {
            String staffId = staffIdField.getText().trim();
            if (!staffId.isEmpty()) {
                attendance.punchIn(staffId);
                addToTable(staffId, "PUNCH IN");
            }
        });

        punchOutButton.addActionListener(e -> {
            String staffId = staffIdField.getText().trim();
            if (!staffId.isEmpty()) {
                attendance.punchOut(staffId);
                addToTable(staffId, "PUNCH OUT");
            }
        });
    }

    private void addToTable(String staffId, String action) {
        String dateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        tableModel.addRow(new Object[]{staffId, action, dateTime});
    }
}
