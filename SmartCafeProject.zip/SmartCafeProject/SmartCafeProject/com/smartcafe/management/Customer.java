package com.smartcafe.management;

import java.util.ArrayList;

public class Customer {
    private String name;
    private int id;
    private ArrayList<String> preferredItems = new ArrayList<>();

    public Customer(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public void addPreferredItem(String item) {
        preferredItems.add(item);
    }

    public ArrayList<String> getPreferredItems() {
        return preferredItems;
    }
}
