package com.smartcafe.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class OrderWindow {

    public static void showOrderWindow() {
        JFrame frame = new JFrame("Place Order");
        frame.setSize(450, 400);
        frame.setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(5, 2));

        JLabel nameLabel = new JLabel("Customer Name:");
        JTextField nameField = new JTextField();

        JLabel itemLabel = new JLabel("Select Item:");
        JComboBox<String> itemBox = new JComboBox<>();
        for (String item : Menu.getAllItems().keySet()) {
            itemBox.addItem(item);
        }

        JLabel qtyLabel = new JLabel("Quantity:");
        JTextField qtyField = new JTextField();

        JButton addItemBtn = new JButton("Add Item to Order");

        DefaultListModel<String> orderListModel = new DefaultListModel<>();
        JList<String> orderList = new JList<>(orderListModel);
        JScrollPane orderScrollPane = new JScrollPane(orderList);

        ArrayList<String> allItems = new ArrayList<>();

        addItemBtn.addActionListener(e -> {
            String selectedItem = (String) itemBox.getSelectedItem();
            String qtyStr = qtyField.getText().trim();

            try {
                if (selectedItem == null || qtyStr.isEmpty()) {
                    throw new InvalidOrderException("Select item and enter quantity.");
                }

                int qty = Integer.parseInt(qtyStr);
                if (qty <= 0) throw new InvalidOrderException("Quantity must be > 0");

                for (int i = 0; i < qty; i++) {
                    allItems.add(selectedItem);
                }
                orderListModel.addElement(qty + " x " + selectedItem);
                qtyField.setText(""); // clear field

            } catch (InvalidOrderException ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Quantity must be a number.");
            }
        });

        JButton placeOrderBtn = new JButton("Place Order");
        placeOrderBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            if (name.isEmpty() || allItems.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Enter customer name and add items.");
                return;
            }

            try {
                Customer customer = new Customer(name, (int)(Math.random() * 1000));
                Order order = new Order(customer, allItems);
                order.calculateTotal();
                BillWindow.showBill(order);
                JOptionPane.showMessageDialog(frame, "Order placed successfully!");
                frame.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
            }
        });

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(e -> frame.dispose());

        formPanel.add(nameLabel);
        formPanel.add(nameField);
        formPanel.add(itemLabel);
        formPanel.add(itemBox);
        formPanel.add(qtyLabel);
        formPanel.add(qtyField);
        formPanel.add(new JLabel());
        formPanel.add(addItemBtn);

        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.add(placeOrderBtn);
        bottomPanel.add(cancelBtn);

        frame.add(formPanel, BorderLayout.NORTH);
        frame.add(orderScrollPane, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}
