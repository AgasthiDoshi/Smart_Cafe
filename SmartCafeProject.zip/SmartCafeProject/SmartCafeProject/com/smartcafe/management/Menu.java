package com.smartcafe.management;

import java.util.HashMap;

public class Menu {
    private static HashMap<String, Double> items = new HashMap<>();

    static {
        // Beverages
        items.put("Masala Chai", 30.0);
        items.put("Filter Coffee", 40.0);
        items.put("Cold Coffee", 70.0);
        items.put("Ginger Tea", 25.0);
        items.put("Lassi", 50.0);
        items.put("Sweet Lime Juice", 40.0);
        items.put("Ganne ka juice (bada gilaas)", 20.0);
        items.put("Ganne ka juice (chota gilaas)", 10.0);
        items.put("Buttermilk (Chaas)", 20.0);
        items.put("Badam Milk", 60.0);

        // Snacks
        items.put("Veg Sandwich", 60.0);
        items.put("Grilled Cheese Sandwich", 90.0);
        items.put("Paneer Sandwich", 100.0);
        items.put("Vada Pav", 20.0);
        items.put("Misal Pav", 50.0);
        items.put("Pav Bhaji", 80.0);
        items.put("Samosa", 15.0);
        items.put("Kachori", 20.0);
        items.put("Veg Puff", 25.0);
        items.put("Egg Puff", 30.0);

        // Fast Food
        items.put("Veg Burger", 65.0);
        items.put("Paneer Burger", 85.0);
        items.put("French Fries", 70.0);
        items.put("Masala Fries", 80.0);
        items.put("Maggi", 40.0);
        items.put("Cheese Maggi", 60.0);
        items.put("Momos (Steamed)", 100.0);
        items.put("Momos (Fried)", 120.0);
        items.put("Chole Bhature", 90.0);
        items.put("Rajma Chawal", 80.0);

        // South Indian
        items.put("Idli Sambar", 50.0);
        items.put("Medu Vada", 40.0);
        items.put("Masala Dosa", 80.0);
        items.put("Plain Dosa", 60.0);
        items.put("Onion Uttapam", 70.0);
        items.put("Upma", 45.0);

        // Desserts
        items.put("Gulab Jamun (2 pcs)", 30.0);
        items.put("Rasgulla (2 pcs)", 30.0);
        items.put("Ice Cream Scoop", 40.0);
        items.put("Chocolate Cake Slice", 60.0);
        items.put("Brownie", 70.0);
        items.put("Kheer", 50.0);
        items.put("Halwa", 40.0);

        // Breads and Combos
        items.put("Aloo Paratha with Curd", 60.0);
        items.put("Paneer Paratha with Curd", 80.0);
        items.put("Chai + Parle-G Combo", 35.0);
        items.put("Coffee + Sandwich Combo", 120.0);

        // Premium
        items.put("Cheese Burst Pizza (Small)", 150.0);
        items.put("Tandoori Paneer Wrap", 100.0);
        items.put("Choco Lava Cake", 90.0);
        items.put("Mocktail", 80.0);
        items.put("Virgin Mojito", 70.0);
    }

    public static void displayMenu() {
        System.out.println("----- Menu -----");
        items.forEach((item, price) ->
            System.out.println(item + " - Rs. " + price));
    }

    public static Double getPrice(String item) throws InvalidOrderException {
        if (!items.containsKey(item)) {
            throw new InvalidOrderException("Item not found: " + item);
        }
        return items.get(item);
    }

    public static boolean isItemAvailable(String item) {
        return items.containsKey(item);
    }

    public static HashMap<String, Double> getAllItems() {
        return items;
    }
}
