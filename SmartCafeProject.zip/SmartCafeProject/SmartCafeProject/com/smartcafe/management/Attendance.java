package com.smartcafe.management;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

public class Attendance {
    private HashMap<String, LocalDateTime> punchInMap = new HashMap<>();
    private HashMap<String, LocalDateTime> punchOutMap = new HashMap<>();
    private static final String FILE_PATH = "staff_attendance.csv";

    public void punchIn(String staffId) {
        LocalDateTime now = LocalDateTime.now();
        punchInMap.put(staffId, now);
        System.out.println("Punch in recorded for " + staffId);
        logToCSV(staffId, "PUNCH IN", now);
    }

    public void punchOut(String staffId) {
        LocalDateTime now = LocalDateTime.now();
        punchOutMap.put(staffId, now);
        System.out.println("Punch out recorded for " + staffId);
        logToCSV(staffId, "PUNCH OUT", now);
    }

    public void showAttendance(String staffId) {
        System.out.println("Attendance for: " + staffId);
        System.out.println("Punch In: " + punchInMap.getOrDefault(staffId, null));
        System.out.println("Punch Out: " + punchOutMap.getOrDefault(staffId, null));
    }

    private void logToCSV(String staffId, String action, LocalDateTime dateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String record = staffId + "," + action + "," + dateTime.format(formatter) + "\n";

        try (FileWriter writer = new FileWriter(FILE_PATH, true)) {
            writer.write(record);
        } catch (IOException e) {
            System.err.println("Error writing to CSV: " + e.getMessage());
        }
    }
}
