package com.smartcafe.management;

import java.util.HashMap;

public class SmartRecommender {
    private HashMap<String, Integer> frequencyMap = new HashMap<>();

    public void recordOrder(String item) {
        frequencyMap.put(item, frequencyMap.getOrDefault(item, 0) + 1);
    }

    public String recommend() {
        return frequencyMap.entrySet().stream()
                .max((a, b) -> a.getValue() - b.getValue())
                .map(entry -> entry.getKey())
                .orElse("Try something new today!");
    }
}
