package com.smartcafe.management;

import javax.swing.*;
import java.awt.*;

public class BillWindow {

    public static void showBill(Order order) {
        JFrame frame = new JFrame("Bill for Order ID: " + order.getOrderId());
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        JTextArea billArea = new JTextArea();
        billArea.setEditable(false);

        StringBuilder billText = new StringBuilder();
        billText.append("Smart Cafe\n");
        billText.append("Order ID: ").append(order.getOrderId()).append("\n");
        billText.append("Customer: ").append(order.getCustomer().getName()).append("\n");
        billText.append("-----------------------------\n");

        for (String item : order.getItems()) {
            try {
                double price = Menu.getPrice(item);
                billText.append(item).append(" - Rs. ").append(price).append("\n");
            } catch (InvalidOrderException e) {
                billText.append(item).append(" - Error: ").append(e.getMessage()).append("\n");
            }
        }

        billText.append("-----------------------------\n");
        billText.append("Total: Rs. ").append(order.getTotal()).append("\n");

        billArea.setText(billText.toString());

        frame.add(new JScrollPane(billArea), BorderLayout.CENTER);

        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> frame.dispose());
        frame.add(closeBtn, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}
