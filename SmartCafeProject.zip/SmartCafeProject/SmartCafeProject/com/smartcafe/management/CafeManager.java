package com.smartcafe.management;

public class CafeManager extends Thread {
    private Order order;

    public CafeManager(Order order) {
        this.order = order;
    }

    @Override
    public void run() {
        try {
            System.out.println("Processing order by thread: " + Thread.currentThread().getName());
            Thread.sleep(1000);
            order.calculateTotal();
            order.generateBill();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
