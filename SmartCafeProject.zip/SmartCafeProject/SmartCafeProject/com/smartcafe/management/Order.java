package com.smartcafe.management;

import java.util.ArrayList;
import java.util.Arrays;

public class Order implements Billable {
    private static int counter = 1;
    private int orderId;
    private Customer customer;
    private ArrayList<String> items;
    private double total;

    public Order(Customer customer) {
        this(customer, new ArrayList<>());
    }

    public Order(Customer customer, ArrayList<String> items) {
        this.orderId = counter++;
        this.customer = customer;
        this.items = items != null ? items : new ArrayList<>();
    }

    public void addItem(String item) throws InvalidOrderException {
        if (item == null || item.trim().isEmpty()) return;

        item = item.trim();
        if (!Menu.isItemAvailable(item)) {
            throw new InvalidOrderException("Invalid item: " + item);
        }
        items.add(item);
    }

    // ✅ Optional helper if you use comma-separated item input like "Tea, Sandwich"
    public void setItemsFromString(String input) throws InvalidOrderException {
        if (input == null || input.trim().isEmpty()) return;

        String[] splitItems = input.split(",");
        for (String item : splitItems) {
            addItem(item.trim());
        }
    }

    public void calculateTotal() throws InvalidOrderException {
        total = 0;
        for (String item : items) {
            total += Menu.getPrice(item);
        }
    }

    @Override
    public void generateBill() {
        System.out.println("\nBill for Order ID: " + orderId);
        items.forEach(item -> System.out.println("- " + item));
        System.out.println("Total: Rs. " + total);
    }

    // ✅ Getter methods

    public int getOrderId() {
        return orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public ArrayList<String> getItems() {
        return items;
    }

    public double getTotal() {
        return total;
    }
}
