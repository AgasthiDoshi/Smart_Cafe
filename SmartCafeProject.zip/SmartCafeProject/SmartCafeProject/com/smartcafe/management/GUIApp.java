package com.smartcafe.management;

import javax.swing.*;
import java.awt.*;

public class GUIApp {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginWindow login = new LoginWindow();
            login.setVisible(true);
        });
    }

    // This is called only after successful login
    public static void launchMainApp() {
        JFrame frame = new JFrame("Smart Cafe Management System");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(5, 1));

        JLabel title = new JLabel("Welcome to Smart Cafe", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        frame.add(title);

        JButton viewMenuBtn = new JButton("View Menu");
        JButton placeOrderBtn = new JButton("Place Order");
        JButton attendanceBtn = new JButton("Staff Attendance");
        JButton exitBtn = new JButton("Exit");

        // ✅ View Menu with only vertical scroll
        viewMenuBtn.addActionListener(e -> {
            StringBuilder menuText = new StringBuilder("------ Smart Cafe Menu ------\n\n");
            Menu.getAllItems().forEach((item, price) -> {
                menuText.append(item).append(" - Rs. ").append(String.format("%.2f", price)).append("\n");
            });

            JTextArea textArea = new JTextArea(menuText.toString());
            textArea.setEditable(false);
            textArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scrollPane.setPreferredSize(new Dimension(350, 400));

            JOptionPane.showMessageDialog(frame, scrollPane, "Cafe Menu", JOptionPane.INFORMATION_MESSAGE);
        });

        placeOrderBtn.addActionListener(e -> {
            OrderWindow.showOrderWindow(); // Open order window
        });

        attendanceBtn.addActionListener(e -> {
            AttendanceWindow attendanceWindow = new AttendanceWindow();
            attendanceWindow.setVisible(true);
        });

        exitBtn.addActionListener(e -> System.exit(0));

        frame.add(viewMenuBtn);
        frame.add(placeOrderBtn);
        frame.add(attendanceBtn);
        frame.add(exitBtn);

        frame.setVisible(true);
    }
}
